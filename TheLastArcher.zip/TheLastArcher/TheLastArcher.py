import pygame
import sys
import time
from pygame.locals import *
import random
import math

pygame.init()

#window_width = 650
window_width = 450
window_height = 600
global screen
screen = pygame.display.set_mode((window_width, window_height))
clock = pygame.time.Clock()

WHITE = (255, 255, 255)
backgroundcolor = (0, 0, 0)
Gameovertext = pygame.font.Font('freesansbold.ttf', 24)
statstext = pygame.font.Font('freesansbold.ttf', 12)


Playerimg = pygame.image.load('Front.png')
PlayerFrontPart1 = pygame.image.load('FrontPart1.png')
PlayerFrontPart2 = pygame.image.load('FrontPart2.png')
PlayerBackPart1 = pygame.image.load('BackPart1.png')
PlayerBackPart2 = pygame.image.load('BackPart2.png')
PlayerLeftPart1 = pygame.image.load('LeftPart1.png')
PlayerLeftPart2 = pygame.image.load('LeftPart2.png')
PlayerRightPart1 = pygame.image.load('RightPart1.png')
PlayerRightPart2 = pygame.image.load('RightPart2.png')
background = pygame.image.load('Arena.png')
background2 = pygame.image.load('Arena2.png')
startimg = pygame.image.load('Startscreen.png')
arrowimgTR = pygame.image.load('ArrowTR.png')
arrowimgDR = pygame.image.load('ArrowDR.png')
arrowimgTL = pygame.image.load('ArrowTL.png')
arrowimgDL = pygame.image.load('ArrowDL.png')
water = pygame.image.load('Water.png')
SpacePart0 = pygame.image.load('ArrowBaragePart0.png')
SpacePart1 = pygame.image.load('ArrowBaragePart1.png')
SpacePart2 = pygame.image.load('ArrowBaragePart2.png')
SpacePart3 = pygame.image.load('ArrowBaragePart3.png')
medusa = pygame.image.load('Medusa.png')
icewarrior = pygame.image.load('IceWarrior.png')
stats = pygame.image.load('Statsbar.png')
enemyarrowbox = pygame.image.load('Enemyarrowbox.png')
enemyarrowDR = pygame.image.load('EnemyarrowDR.png')
enemyarrowDL = pygame.image.load('EnemyarrowDL.png')
enemyarrowTR = pygame.image.load('EnemyarrowTR.png')
enemyarrowTL = pygame.image.load('EnemyarrowTL.png')
blackbar = pygame.image.load('BlackBar.png')


global archerx
global archery
archerx = 215
archery = 270

global bgx
global bgy
bgx= 0
bgy= 0

global pressed_down
global pressed_up
global pressed_right
global pressed_left
pressed_down = False
pressed_up = False
pressed_right = False
pressed_left = False

global dist
dist = 3

global arrowtimer
arrowtimer = 50

global waterx
global watery
waterx = -300
watery = -300

global backtimer
global fronttimer
global lefttimer
global righttimer
global playerhittimer
backtimer = 0
fronttimer = 0
lefttimer = 0
righttimer = 0
playerhittimer = 0

global currentlevel
global currnthealth
global totalhealth
global currentxp
global totalxp
currentlevel = 1
currenthealth = 200
totalhealth = 200
currentxp = 0
totalxp = 50

global wdown
global sdown
global adown
global ddown
wdown = 0
sdown = 0
adown = 0
ddown = 0

global spacedownnum
spacedownnum = 0

global spacedowntrue
spacedowntrue = False

global spacedowncheck
spacedowncheck = 100

global mana
global totalmana
mana = 100
totalmana = 100

global regentimer
global regennumber
regentimer = 0
regennumber = 80

global enemyx
global enemyy
enemyx = 0
enemyy = 0

global spacedownyes
spacedownyes = 0

global checkvar
global enemyhitvar
global shootvar
checkvar = 0
enemyhitvar = 0
shootvar = 5

global enemydeadtimer
global enemydeadcounter
enemydeadtimer = False
enemydeadcounter = 0


global randomxvar1
global randomxvar2
global randomyvar1
global randomyvar2
randomxvar1 = 2837
randomxvar2 = 5300
randomyvar1 = 4304
randomyvar2 = 6200

global xtempvar
global ytempvar
xtempvar = 0
ytempvar = 0

global randnum
randnum = 0

global enemyarrowx
global enemyarrowy
enemyarrowx = 400
enemyarrowy = 650

global maingamevar
maingamevar = 1


class PlayerEntity(pygame.sprite.Sprite):
    """Inherited by any object in the game."""

    def __init__(self, archerx, archery, width, height):
        pygame.sprite.Sprite.__init__(self)

        self.x = archerx
        self.y = archery
        self.width = 32
        self.height = 32
        self.rect = pygame.Rect(self.x, self.y, self.width, self.height)

class EnemyEntity(pygame.sprite.Sprite):
    """Inherited by any object in the game."""

    def __init__(self, enemyx, enemyy, width, height):
        pygame.sprite.Sprite.__init__(self)

        global randomxvar1
        global randomxvar2
        global randomyvar1
        global randomyvar2

        self.x = random.randint(randomxvar1, randomxvar2)
        self.y = random.randint(randomyvar1, randomyvar2)
        # self.x = enemyx
        # self.y = enemyy
        self.width = 64
        self.height = 64
        self.rect = pygame.Rect(self.x, self.y, self.width, self.height)

class Archer(PlayerEntity):
    def __init__(self, x, y, width, height):
        super(Archer, self).__init__(x, y, width, height)

        self.image = Playerimg

class Enemies(EnemyEntity):
    def __init__(self, x, y, width, height):
        super(Enemies, self).__init__(x, y, width, height)

        global randnum
        randnum = random.randint(0, 1)

        if randnum == 0:
            self.image = icewarrior
        elif randnum == 1:
            self.image = medusa

        global hit
        hit = False

class Player(Archer):

    def __init__(self, x, y, width, height):
        super(Player, self).__init__(x, y, width, height)

class Water(pygame.sprite.Sprite):
    def __init__(self, waterx, watery, width, height):
        pygame.sprite.Sprite.__init__(self)
        self.x = waterx
        self.y = watery
        self.width = 5800
        self.height = 7733
        self.image = water
        self.rect = pygame.Rect(self.x, self.y, self.width, self.height)

class Space(pygame.sprite.Sprite):
    def __init__(self, x, y, width, height):
        pygame.sprite.Sprite.__init__(self)
        global spacex
        global spacey
        self.x = spacex
        self.y = spacey
        self.width = 64
        self.height = 64
        self.image = SpacePart0
        self.rect = pygame.Rect(self.x, self.y, self.width, self.height)

    def update(self):
        global spacedownnum
        global spacedowntrue
        global space
        global spacedownyes

        if spacedownyes == 0:
            if (spacedownnum == 1):
                space.image = SpacePart1
            elif spacedownnum > 6 and spacedownnum < 11:
                space.image = SpacePart2
            elif spacedownnum >= 11 and spacedownnum <= 16:
                space.image = SpacePart3


            if spacedownnum > 16:
                all_sprites_list.remove(space)
                spacedownnum = 0
                spacedowntrue = False
                space.image = SpacePart0
                spacedownyes = 1


class Map(pygame.sprite.Sprite):
    global bgx
    global bgy

    def __init__(self, bgx, bgy, width, height):
        pygame.sprite.Sprite.__init__(self)

        global pressed_down
        global pressed_up
        global pressed_right
        global pressed_left
        self.y_change = 0
        self.x_change = 0
        self.y_dist = 3
        self.x_dist = 3
        self.x = 0
        self.y = 0
        self.width = 450
        self.height = 600
        self.image = background2
        self.rect = pygame.Rect(self.x, self.y, self.width, self.height)

    def MoveKeyUp(self, key):
        global bgx
        global bgy
        global player
        global wdown
        global sdown
        global adown
        global ddown
        if (key == pygame.K_w):
            bgy += -self.y_dist
            wdown = 0
            player.image = Playerimg
        elif (key == pygame.K_s):
            bgy += self.y_dist
            sdown = 0
            player.image = Playerimg
        elif (key == pygame.K_a):
            bgx += -self.x_dist
            adown = 0
            player.image = Playerimg
        elif (key == pygame.K_d):
            bgx += self.x_dist
            ddown = 0
            player.image = Playerimg

    def MoveKeyDown(self, key):
        leftimages = ['LeftPart1.png', 'LeftPart2.png']
        rightimages = ['RightPart1.png', 'RightPart2.png']
        frontimages = ['FrontPart1.png', 'FrontPart2.png']
        backimages = ['BackPart1.png', 'BackPart2.png']
        leftcounter = 0
        rightcounter = 0
        frontcounter = 0
        backcounter = 0
        global player
        global bgx
        global bgy
        global backtimer
        global fronttimer
        global righttimer
        global lefttimer
        global wdown
        global sdown
        global adown
        global ddown
        global arrow
        global enemy
        global enemyx
        global enemyy


        if (key == pygame.K_w):
            bgy += self.y_dist
            wdown = 1

        elif (key == pygame.K_s):
            bgy += -self.y_dist
            sdown = 1

        elif (key == pygame.K_a):
            bgx += self.x_dist
            adown = 1

        elif (key == pygame.K_d):
            bgx += -self.x_dist
            ddown = 1

    def update(self):
        global bgx
        global bgy
        global watersprite
        global backtimer
        global backtimer
        global fronttimer
        global righttimer
        global lefttimer
        global mousex
        global mousey
        global enemyx
        global enemyy
        global xtempvar
        global ytempvar
        """
        Moves the player while ensuring it stays in bounds
        """

        if (wdown == 1):
            if self.rect.y == 254:
                pass
            else:
                try:
                    enemy.rect.y += self.y_dist
                    space.rect.y += self.y_dist
                    ytempvar += self.y_dist
                    # arrow.rect.y += self.y_dist
                    # mousey += self.y_dist
                except:
                    pass

                try:
                    if backtimer > 15 and backtimer < 30:
                        player.image = PlayerBackPart1
                    elif backtimer >= 30:
                        player.image = PlayerBackPart2
                        backtimer = 0
                except:
                    pass

        if (sdown == 1):
            if self.rect.y == -5970:
                pass
            else:
                try:
                    enemy.rect.y += -self.y_dist
                    space.rect.y += -self.y_dist
                    ytempvar += -self.y_dist
                    # arrow.rect.y += -self.y_dist
                    # mousey += -self.y_dist
                except:
                    pass

                try:
                    if fronttimer > 15 and fronttimer < 30:
                        player.image = PlayerFrontPart1
                    elif fronttimer >= 30:
                        player.image = PlayerFrontPart2
                        fronttimer = 0
                except:
                    pass
        if (adown == 1):
            if self.rect.x == 199:
                pass
            else:
                try:
                    enemy.rect.x += self.x_dist
                    space.rect.x += self.x_dist
                    xtempvar += self.x_dist
                    # arrow.rect.x += self.x_dist
                    # mousex += self.x_dist
                except:
                    pass

                try:
                    if lefttimer > 15 and lefttimer < 30:
                        player.image = PlayerLeftPart1
                    elif lefttimer >= 30:
                        player.image = PlayerLeftPart2
                        lefttimer = 0
                except:
                    pass
        if (ddown == 1):
            if self.rect.x == -5138:
                pass
            else:
                try:
                    enemy.rect.x += -self.x_dist
                    space.rect.x += -self.x_dist
                    xtempvar += -self.x_dist
                    # arrow.rect.x += -self.x_dist
                    # mousex += -self.x_dist
                except:
                    pass

                try:
                    if righttimer > 15 and righttimer < 30:
                        player.image = PlayerRightPart1
                    elif righttimer >= 30:
                        player.image = PlayerRightPart2
                        righttimer = 0
                except:
                    pass

        self.rect.move_ip(bgx, 0)
        self.rect.move_ip(0, bgy)

        watersprite.rect.move_ip(bgx, 0)
        watersprite.rect.move_ip(0, bgy)
        if self.rect.x < -5137:
            self.rect.x = -5138
        elif self.rect.x > 199:
            self.rect.x = 199
        if self.rect.y < -5970:
            self.rect.y = -5970
        elif self.rect.y > 254:
            self.rect.y = 254

        if watersprite.rect.x < -5453:
            watersprite.rect.x = -5453
        elif watersprite.rect.x > -85:
            watersprite.rect.x = -85
        if watersprite.rect.y < -6286:
            watersprite.rect.y = -6286
        elif watersprite.rect.y > -30:
            watersprite.rect.y = -30

class Enemy(Enemies):
    """
    AI controlled enemy, simply moves towards the player
    and nothing else.
    """

    def __init__(self, x, y, width, height):
        super(Enemy, self).__init__(x, y, width, height)

        self.y_change = 4
        self.x_change = 4
        self.speed = 2

    def update(self):
        """
        Moves the enemy while ensuring it stays in bounds
        """
        # Moves the enemy up if the player is moves away
        # if player.rect.y < self.rect.y:
        #     self.rect.y -= self.y_change
        # elif player.rect.y > self.rect.y:
        #     self.rect.y += self.y_change
        # elif player.rect.x < self.rect.x:
        #     self.rect.x -= self.x_change
        # elif player.rect.x > self.rect.x:
        #     self.rect.x += self.x_change
        global tempvar1
        global tempvar2
        global enemytempvar1
        global enemytempvar2
        global player
        testnumx = abs(self.rect.x - player.rect.x)
        testnumy = abs(self.rect.y - player.rect.y)
        try:
            global enemygonum
            if enemygonum == 0:
                if testnumx <= 270 and testnumy <= 320:
                    try:
                        # find normalized direction vector (dx, dy) between enemy and player
                        dx, dy = self.rect.x - (player.rect.x - 16), self.rect.y - (player.rect.y - 16)
                        dist = math.hypot(dx, dy)
                        dx, dy = (dx / dist), (dy / dist)
                        # move along this normalized vector towards the player at current speed
                        self.rect.x -= dx * self.speed
                        self.rect.y -= dy * self.speed
                    except ZeroDivisionError:
                        pass
                else:
                    pass
            else:
                pass
        except NameError:
            pass



class Arrow(pygame.sprite.Sprite):
    """ This class represents the bullet . """

    def __init__(self):
        # Call the parent class (Sprite) constructor
        super().__init__()

        self.image = arrowimgDR
        self.speed = 4
        self.rect = self.image.get_rect()
        self.x_change = 4
        self.y_change = 4

    def update(self):
        """ Move the arrow. """
        global waittime
        global mousedown
        xdiff = (abs(mousex - player.rect.x))
        ydiff = (abs(mousey - player.rect.y))
        angle = math.atan2(ydiff, xdiff)
        self.angle = math.degrees(angle)
        if mousex > player.rect.x and mousey > player.rect.y:
            if mousedown == 1:
                DR = arrowimgDR
                if self.angle >= 45:
                    angleDR = (45 - self.angle)
                elif self.angle <= 45:
                    angleDR = (45 - self.angle)
                DR = pygame.transform.rotate(DR, angleDR)
                mousedown = 0
                self.image = DR
            else:
                pass
            ax, ay = player.rect.x - mousex, player.rect.y - mousey
            dist = math.hypot(ax, ay)
            ax, ay = (ax / dist), (ay / dist)
            self.rect.x -= ax * self.speed
            self.rect.y -= ay * self.speed
        elif mousex < player.rect.x and mousey > player.rect.y:
            if mousedown == 1:
                DL = arrowimgDL
                if self.angle >= 45:
                    angleDL = (self.angle - 45)
                elif self.angle <= 45:
                    angleDL = (self.angle - 45)
                DL = pygame.transform.rotate(DL, angleDL)
                mousedown = 0
                self.image = DL
            else:
                pass
            ax, ay = player.rect.x - mousex, player.rect.y - mousey
            dist = math.hypot(ax, ay)
            ax, ay = (ax / dist), (ay / dist)
            self.rect.x -= ax * self.speed
            self.rect.y -= ay * self.speed
        elif mousex > player.rect.x and mousey < player.rect.y:
            if mousedown == 1:
                TR = arrowimgTR
                if self.angle >= 45:
                    angleTR = (self.angle - 45)
                elif self.angle <= 45:
                    angleTR = (self.angle - 45)
                TR = pygame.transform.rotate(TR, angleTR)
                mousedown = 0
                self.image = TR
            else:
                pass
            ax, ay = player.rect.x - mousex, player.rect.y - mousey
            dist = math.hypot(ax, ay)
            ax, ay = (ax / dist), (ay / dist)
            self.rect.x -= ax * self.speed
            self.rect.y -= ay * self.speed
        elif mousex < player.rect.x and mousey < player.rect.y:
            if mousedown == 1:
                TL = arrowimgTL
                if self.angle >= 45:
                    angleTL = (45 - self.angle)
                elif self.angle <= 45:
                    angleTL = (45 - self.angle)
                TL = pygame.transform.rotate(TL, angleTL)
                mousedown = 0
                self.image = TL
            else:
                pass
            ax, ay = player.rect.x - mousex, player.rect.y - mousey
            dist = math.hypot(ax, ay)
            ax, ay = (ax / dist), (ay / dist)
            self.rect.x -= ax * self.speed
            self.rect.y -= ay* self.speed
        else:
            all_sprites_list.remove(self)



        if self.rect.x > 420 or self.rect.x < 20:
            all_sprites_list.remove(self)
        elif self.rect.y > 490 or self.rect.y < 20:
            all_sprites_list.remove(self)

        if self.rect.colliderect(enemy.rect):
            global enemyhitvar
            global shootvar
            global enemydeadtimer
            all_sprites_list.remove(self)
            enemyhitvar += 1
            print(enemyhitvar)
            if enemyhitvar == 10:
                all_sprites_list.remove(enemy)
                enemy.rect.x = - 10000
                enemy.rect.y = - 10000
                shootvar -= 1
                enemydeadtimer = True

class PointingArrow(pygame.sprite.Sprite):
    def __init__(self, enemyarrowx, enemyarrowy, width, height):
        super().__init__()

        self.image = enemyarrowDR
        self.x = 170
        self.y = 470
        self.width = 64
        self.height = 64
        self.image = enemyarrowDR
        self.rect = pygame.Rect((self.x + 32), (self.y + 32), self.width, self.height)

    def update(self):
        global enemyxdiff
        global enemyydiff
        enemyxdiff = (abs(enemy.rect.x - player.rect.x))
        enemyydiff = (abs(enemy.rect.y - player.rect.y))
        enemyangle = math.atan2(enemyydiff, enemyxdiff)
        self.angle = math.degrees(enemyangle)

        if enemy.rect.x > player.rect.x and enemy.rect.y > player.rect.y:
            EnemyDR = enemyarrowDR
            if self.angle >= 45:
                angleDR = (45 - self.angle)
            elif self.angle <= 45:
                angleDR = (45 - self.angle)
            EnemyDR = pygame.transform.rotate(EnemyDR, angleDR)
            self.image = EnemyDR

        elif enemy.rect.x < player.rect.x and enemy.rect.y > player.rect.y:
            EnemyDL = enemyarrowDL
            if self.angle >= 45:
                angleDL = (self.angle - 45)
            elif self.angle <= 45:
                angleDL = (self.angle - 45)
            EnemyDL = pygame.transform.rotate(EnemyDL, angleDL)
            self.image = EnemyDL

        elif enemy.rect.x > player.rect.x and enemy.rect.y < player.rect.y:
            EnemyTR = enemyarrowTR
            if self.angle >= 45:
                angleTR = (self.angle - 45)
            elif self.angle <= 45:
                angleTR = (self.angle - 45)
            EnemyTR = pygame.transform.rotate(EnemyTR, angleTR)
            self.image = EnemyTR

        elif enemy.rect.x < player.rect.x and enemy.rect.y < player.rect.y:
            EnemyTL = enemyarrowTL
            if self.angle >= 45:
                angleTL = (45 - self.angle)
            elif self.angle <= 45:
                angleTL = (45 - self.angle)
            EnemyTL = pygame.transform.rotate(EnemyTL, angleTL)
            self.image = EnemyTL

        else:
            pass


def Startscreen():
    while True:
        screen.blit(startimg, (0, 0))
        #screen.blit(titleimg, (100, 100))
        StartObj = Gameovertext.render('Press space to start', True, WHITE)
        Startrect = StartObj.get_rect()
        Startrect.center = (225, 250)
        for event in pygame.event.get():
            if event.type == KEYDOWN:
                if event.key == K_SPACE:
                    startscreentrue = True
                    if startscreentrue == True:
                        screen.fill(backgroundcolor)
                        LoadingObj = Gameovertext.render('Loading...', True, WHITE)
                        Loadingrect = LoadingObj.get_rect()
                        Loadingrect.center = (225, 250)
                        screen.blit(LoadingObj, Loadingrect)
                        pygame.display.flip()
                        time.sleep(1)
                        Game()
        clock.tick(60)
        pygame.display.flip()

def Game():
    window_height = 700
    screen = pygame.display.set_mode((window_width, window_height))
    global spacedownyes
    global enemygonum
    global regennumber
    global mana
    global spacedowncheck
    global arrowtimer
    global pressed_down
    global pressed_up
    global pressed_right
    global pressed_left
    global bgx
    global bgy
    global map
    global all_sprites_list
    global watersprite
    global player
    global playerhittimer
    global backtimer
    global fronttimer
    global righttimer
    global lefttimer
    global spacedowntrue
    global regentimer
    global totalmana
    global enemy
    global shootvar
    global enemydeadtimer
    global enemydeadcounter
    global xtempvar
    global ytempvar
    global currentlevel
    global currenthealth
    global totalhealth
    global currentxp
    global currentlevel
    global totalxp
    global enemyarrowbox
    global pointingarrow
    global enemyarrowx
    global enemyarrowy
    global maingamevar
    enemygonum = 0
    watersprite = Water(waterx, watery, 5800, 7733)
    map = Map(bgx, bgy, 450, 600)
    player = Player(archerx, archery, 32, 32)
    enemy = Enemy(enemyx, enemyy, 64, 64)
    pointingarrow = PointingArrow(enemyarrowx, enemyarrowy, 64, 64)
    all_sprites_list = pygame.sprite.Group()
    all_sprites_list.add(watersprite)
    all_sprites_list.add(map)
    all_sprites_list.add(player)
    all_sprites_list.add(enemy)
    all_sprites_list.add(pointingarrow)
    #screen.blit(background, (bgx, bgy))
    while True:
        # global a
        # if a == 30:
        #     print(all_sprites_list.sprites())
        #     a = 0
        # a += 1
        regentimer += 1
        spacedowncheck += 1
        arrowtimer += 1
        backtimer += 1
        fronttimer += 1
        lefttimer += 1
        righttimer += 1
        playerhittimer += 1

        # if maingamevar == 1:
        #     all_sprites_list.remove(space)
        #     maingamevar = 0


        if regentimer % regennumber == 0 and mana < totalmana:
            mana += 1

        if regentimer % regennumber == 0 and currenthealth < totalhealth:
            currenthealth += 1

        if enemy.rect.colliderect(player.rect) and playerhittimer >= 50 and currenthealth >= 0:
            currenthealth -= 40
            playerhittimer = 0

        if enemydeadtimer == True:
            enemydeadcounter += 1

        spacemouse = pygame.mouse.get_pos()
        global spacex
        global spacey
        spacex = spacemouse[0] - 32
        spacey = spacemouse[1] - 32

        if spacedowntrue == True:
            global spacedownnum
            spacedownnum += 1
            Space.update(Space)

        if currentxp >= totalxp:
            if currentlevel == 10:
                pass
            else:
                currentlevel += 1
                currentxp = 0
                totalxp += 50

        global arrow
        arrow = Arrow()

        screen.fill(backgroundcolor)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
                pygame.quit()
            elif event.type == pygame.KEYDOWN:
                global space
                space = Space(spacex, spacey, 64, 64)
                mana = int(mana)
                if event.key == K_SPACE and spacedowncheck>100 and mana >= 40:
                    all_sprites_list.add(space)
                    mana -= 40
                    spacedowncheck=0
                    spacedowntrue = True
                    if enemy.rect.colliderect(space.rect):
                        global enemyhitvar
                        enemyhitvar += 4
                        print(enemyhitvar)

                else:
                    map.MoveKeyDown(event.key)

            elif event.type == pygame.KEYUP:
                map.MoveKeyUp(event.key)
            else:
                pass

            if event.type == MOUSEBUTTONDOWN:
                if all_sprites_list.__len__() == shootvar:
                    if arrowtimer >= 20:
                        try:
                            global mousedown
                            mousedown = 1
                            global mousex
                            global mousey
                            mousex, mousey = event.pos
                            # Set the bullet so it is where the player is
                            arrow.rect.x = 223
                            arrow.rect.y = 258
                            arrowtimer = 0
                            # Add the bullet to the lists
                            all_sprites_list.add(arrow)
                        except:
                            pass


        for ent in all_sprites_list:
            ent.update()

            #screen.blit(background, (bgx, bgy))

        all_sprites_list.draw(screen)

        if spacedownyes == 1:
            global checkvar
            for space in all_sprites_list:
                all_sprites_list.remove(space)
                if all_sprites_list.__len__() == 0 and checkvar == 0:
                    checkvar = 1
                    refresh()

        def refresh():
            global spacedownyes
            global checkvar
            global shootvar
            global enemydeadtimer
            spacedownyes = 0
            checkvar = 0
            all_sprites_list.add(watersprite)
            all_sprites_list.add(map)
            all_sprites_list.add(player)
            all_sprites_list.add(pointingarrow)
            if enemyhitvar < 10:
                all_sprites_list.add(enemy)
            elif enemyhitvar >= 10:
                all_sprites_list.remove(enemy)
                enemy.rect.x = - 10000
                enemy.rect.y = - 10000
                shootvar -= 1
                enemydeadtimer = True


        if enemydeadcounter >= 30:
            global randomxvar1
            global randomxvar2
            global randomyvar1
            global randomyvar2
            enemydeadtimer = False
            shootvar += 1
            enemydeadcounter = 0
            enemy = Enemy(enemyx, enemyy, 64, 64)
            all_sprites_list.add(enemy)
            enemy.rect.x = (random.randint(randomxvar1, randomxvar2) - abs(xtempvar)) + 225
            enemy.rect.y = (random.randint(randomyvar1, randomyvar2) - abs(ytempvar)) + 300
            print(enemy.rect.x)
            print(enemy.rect.y)
            enemyhitvar = 0
            if currentlevel == 10:
                pass
            else:
                totalmana += 10
                currentxp += 500
                totalhealth += 40
                currenthealth += 40
                regennumber -= 4

        if currentlevel == 10:
            totalmana = 200
            totalhealth = 600

        if currenthealth <= 0:
            currenthealth = 0
            for i in all_sprites_list:
                all_sprites_list.remove(i)
            window_height = 600
            screen = pygame.display.set_mode((window_width, window_height))
            deadObj = Gameovertext.render('GAME OVER', True, WHITE)
            deadrect = deadObj.get_rect()
            deadrect.center = (225, 250)
            screen.blit(deadObj, deadrect)
            pygame.display.flip()
            YourDead()



        for ent in all_sprites_list:
            ent.update()

        screen.blit(blackbar, (0, 600))


        if currentlevel != 10:
            strcurrentlevel = str(currentlevel)
            LevelObj = statstext.render('Level ' + strcurrentlevel, True, WHITE)
            Levelrect = LevelObj.get_rect()
            Levelrect.center = (50, 630)
            screen.blit(LevelObj, Levelrect)
        elif currentlevel == 10:
            LevelObj = statstext.render('Level MAX', True, WHITE)
            Levelrect = LevelObj.get_rect()
            Levelrect.center = (50, 630)
            screen.blit(LevelObj, Levelrect)


        strcurrentxp = str(currentxp)
        strtotalxp = str(totalxp)
        XpObj = statstext.render(strcurrentxp + '/' + strtotalxp, True, WHITE)
        Xprect = XpObj.get_rect()
        Xprect.center = (50, 660)
        screen.blit(XpObj, Xprect)

        HPObj = statstext.render('Health', True, WHITE)
        HPrect = HPObj.get_rect()
        HPrect.center = (210, 630)
        screen.blit(HPObj, HPrect)

        strcurrenthealth = str(currenthealth)
        strtotalhealth = str(totalhealth)
        HealthObj = statstext.render(strcurrenthealth + '/' + strtotalhealth, True, WHITE)
        Healthrect = HealthObj.get_rect()
        Healthrect.center = (210, 660)
        screen.blit(HealthObj, Healthrect)

        EnergyObj = statstext.render('Energy', True, WHITE)
        Energyrect = EnergyObj.get_rect()
        Energyrect.center = (370, 630)
        screen.blit(EnergyObj, Energyrect)

        strmana = str(mana)
        strtotalmana = str(totalmana)
        ManaObj = statstext.render(strmana + '/' + strtotalmana, True, WHITE)
        Manarect = ManaObj.get_rect()
        Manarect.center = (370, 660)
        screen.blit(ManaObj, Manarect)

        pygame.display.flip()

        clock.tick(60)

        def YourDead():
            time.sleep(2)
            sys.exit()


Startscreen()

